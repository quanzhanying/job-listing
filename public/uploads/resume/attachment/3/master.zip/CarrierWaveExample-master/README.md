CarrierWaveExample
==================

This project provides a working example of using CarrierWave

[See Allowing File Uploads with CarrierWave for a tutorial.] (http://richonrails.com/articles/allowing-file-uploads-with-carrierwave)
